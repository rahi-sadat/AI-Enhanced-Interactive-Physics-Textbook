# Real diagram → simulation forensic trace — 2026-10-16

The current live run fails before producing semantic analysis: the normal Windows backend reaches Gemini, but the provider ends in **503 UNAVAILABLE / high demand**. No uploaded diagram reaches a runnable PhysicsScene. This establishes the current operational blocker, **not the historical cause of displaced or incorrect simulations**. No production code, physics equations, prompts, detector settings, or scene values were fixed.

Open [the visual index](INDEX.html). The primary reports end in `-NATIVE`. Earlier WSL traces are separate, incomplete network diagnostics; do not combine their artifacts with the native requests.

## 1. Active runtime architecture

Verified checkout: `f59652f7cf9adaeb3926d42b390f73c0135b02eb`, with the user's pre-existing uncommitted changes. The recorder used current working-tree source, not a clean historical checkout. The ten pre-existing modified production/test files retain their original diff totals: 125 insertions, 34 deletions. New tools are isolated under `tests/acceptance/`; runtime artifacts are ignored under `storage/generated/`.

The real frontend is Vite at `http://127.0.0.1:5173`, proxying `/api` to FastAPI on port 8000. Native Python is `C:\Users\saher\AppData\Local\Programs\Python\Python312\python.exe`. The application loads its existing `.env` through `apps/api/main.py`. It uses the normal `GeminiVisionProvider` SDK connection. No mock provider, model response substitution, or alternate network tunnel was used.

| Order | Source / component / function | Caller → next component | This run |
|---|---|---|---|
| 1 | `apps/web/src/main.js`, file change handler and `btnGenerate` click listener | Actual file picker change → `orchestrator.startWithFile(uploadedFile)` | EXECUTED |
| 2 | `SimulationOrchestrator.js`, `startWithFile` | Upload handler → `SimulationApi.ingest` | EXECUTED |
| 3 | `SimulationApi.js`, `ingest` | Orchestrator → multipart `POST /api/ingest` via native `fetch` | EXECUTED |
| 4 | `apps/api/main.py:1570`, `ingest_diagram` | FastAPI router → `_get_ingestion_pipeline`, stream file bytes, `UploadService.ingest` | EXECUTED |
| 5 | `ai/ingestion/UploadService.py`, `ingest` | API → OpenCV decode, SHA-256, original byte persistence, SourceAsset | EXECUTED |
| 6 | `ai/ingestion/PageIRBuilder.py`, `build` | API → full-image PageIR | EXECUTED |
| 7 | `ai/ingestion/BookUnderstandingPipeline.py`, `analyze` | API `asyncio.to_thread` → `PhysicsVisionAnalyzer.analyze` | EXECUTED |
| 8 | `ai/ingestion/vision/analyzer.py`, `analyze` | Book pipeline → read SourceAsset bytes → provider | EXECUTED |
| 9 | `ai/ingestion/vision/gemini_provider.py`, `analyze_diagram` | Analyzer → SDK `Models.generate_content` → `_generate_content` | EXECUTED; provider failure |
| 10 | `BookUnderstandingPipeline._build_unresolved_ir` | Caught `VisionProviderError` → unresolved BookIR | EXECUTED |
| 11 | `ai/evidence/pipeline.py`, `EvidenceExtractionPipeline.extract_and_fuse` | API thread → early return for null domain/subtype | EXECUTED wrapper; extractors NOT EXECUTED |
| 12 | `ai/ingestion/source_dimensions.py`, `enforce_source_dimensions` | API → retain SourceAsset width/height in BookIR | EXECUTED |
| 13 | `ai/resolution/auto.py`, `AutoResolutionEngine.resolve` | API thread → `RequirementRegistry.get_spec`, `ReadinessEvaluator.evaluate` | EXECUTED; CLASSIFICATION_FAILED |
| 14 | `ai/resolution/engine.py`, `ResolutionEngine.auto_resolve` | API thread → readiness/analyzer | EXECUTED; remains unresolved |
| 15 | `ai/resolution/evaluator.py`, `ReadinessEvaluator.evaluate` | Auto-resolution → `ResolutionAnalyzer.analyze` | EXECUTED; ready=false |
| 16 | `ai/ingestion/PhysicsCompiler.py`, `PhysicsCompiler.compile` | API thread → null-domain/subtype gate | EXECUTED; scene=null |
| 17 | `ingest_diagram` response → `SimulationApi.ingest` → `SimulationOrchestrator.startWithFile` | HTTP 200 / status unresolved → provider-error UI branch | EXECUTED; browser ERROR |

The live compiler implementation is **`ai/ingestion/PhysicsCompiler.py`**. `ai/scene_compiler/physics_compiler.py` re-exports it; it is not a second active compiler.

These are the reachable success branches found in the current source, **NOT EXECUTED for these native uploads**:

```
EvidenceExtractionPipeline
  → load_and_validate_source_image
  → MultiOCRRouter.extract
  → subtype CV extractor
  → SAM2 segment only if the proposal has a bob and the provider is available
  → subtype Grounder.ground
  → grounded BookIR
  → auto-resolution/readiness
  → PhysicsCompiler._build_canonical_scene / subtype population
  → HTTP scene
  → SimulationOrchestrator._normalizeSceneBackground
  → InteractiveFigure.load
      → FigureViewport.setBackground / CoordinateMapper
      → RendererRegistry (optics or circuits)
      → PhysicsRuntime.load
          → normalizeLegacyScene / validatePhysicsScene
          → capability registry
          → SolverRegistry.resolve
          → domain adapter.initialize
      → initial renderer.render(runtime.getOutput())
  → orchestrator.startSimulation / activeFigure.play
```

Domain branches are `ThinLensCVCandidateExtractor` → optics grounder → `OpticsAdapter`/`thinLensEngine`; `PrismCVCandidateExtractor` → prism grounder → `OpticsAdapter`/`prismEngine`; `PendulumCVCandidateExtractor` → pendulum grounder → `MechanicsAdapter`/`pendulumSimulation`; and `CircuitCVCandidateExtractor` → circuit grounder → `CircuitAdapter`/`CircuitCompiler`/`CircuitSolver.solveDC`. `OpticsRenderer` and `CircuitRenderer` consume their runtime outputs. Mechanics uses its adapter/simulation rendering rather than an entry in the two-domain renderer registry.

The uploaded-file branch returns before the legacy preset flow. `/api/upload-diagram`, `/api/analyze-diagram`, and the preset `sceneRouter` route were not the upload path. The current `main.js` automatically calls Start/Play on a successful compiled upload; the documentation's separate explicit Start requirement does not describe that current handler. That branch was not reached here.

## 2. Trace results — Diagram 1: convex lens

[Every captured stage, full data, source overlay, and screenshot](TRACE-LENS-20261016-001-NATIVE/TRACE_REPORT.html).

- Original JPEG: 1280 × 960, no EXIF orientation tag. SHA-256: `b1146c485899630e983706b53cce5f2320164bc1d7324bfb1c47ff2b7dab7c5c`.
- Uploaded bytes, persisted SourceAsset, and SDK image part match exactly. PageIR is the full source frame, with no resize or crop.
- Provider executes six SDK calls, two for each configured model: `gemini-3.1-flash-lite`, `gemini-3.8-flash`, `gemini-3-flash-preview`. Terminal error: 503 UNAVAILABLE.
- The provider does not return a domain, subtype, entities, confidence, visible labels, or geometry. The downstream null/zero/empty fields are failure representations created by repository code, not model output.
- Evidence wrapper returns early; auto-resolution and readiness decline; compiler returns `DOMAIN_OR_SUBTYPE_UNKNOWN`, `scene: null`; browser enters ERROR.
- Lens center, optical axis, F/2F positions, object/image geometry, rays and source-to-physics calibration: **NOT PRODUCED**. No t=0 image exists for this request.

## 3. Trace results — Diagram 2: series circuit with open switch

[Every captured stage, full data, source overlay, and screenshot](TRACE-CIRCUIT-20261016-002-NATIVE/TRACE_REPORT.html).

- Original JPEG: 1280 × 960. SHA-256: `e5ae133702ba3de2d830330c1bceec2e0d1ea8f97e03f1ce27699b9e1cae1d63`.
- Independent actual UI upload; byte identity verified through the SDK request.
- Terminal provider error and safe downstream result are recorded independently, rather than inferred from the lens.
- No wire detector, component/terminal detector, polarity detector, switch resolver, graph builder, MNA solve, current calculation or current-path renderer executes for this upload. No circuit has been manually reconstructed. The printed numbers and visible switch are source content, not injected runtime evidence.

## 4. Trace results — Diagram 3: pendulum

[Every captured stage, full data, source overlay, and screenshot](TRACE-PENDULUM-20261016-003-NATIVE/TRACE_REPORT.html).

- Original JPEG: 1280 × 960. SHA-256: `b5341f3eb014fc45df72b93b37fefc2de5adee3e4db4e11ec3949bc9475a78fd`.
- Independent actual UI upload and identical SDK image bytes.
- No pivot, bob center, string length, radius, initial angle, mass, gravity, calibration, segmentation prompt, mask or physical state is produced. The app's startup pendulum has ID `PHY-MECH-001` and belongs to a different source; it is explicitly excluded from this trace's results.
- Readiness/compilation outputs in the report must be distinguished from actual solver execution. A compiler call returning `scene: null` is not a pendulum simulation.

## 5. Trace results — Diagram 4: prism

[Every captured stage, full data, source overlay, and screenshot](TRACE-PRISM-20261016-004-NATIVE/TRACE_REPORT.html).

- Original JPEG: 1280 × 960. SHA-256: `59aaf1ff61b692e086a588d9916227a1fc3720e8135095484f99abb335739cd2`.
- Independent UI upload and identity chain, including actual SDK requests.
- No prism vertices, apex angle, refractive index, incident ray, normal, refracted ray, emergent ray or deviation is produced by the active pipeline. No geometrical measurement or idealized ray was invented for the report.

## 6. Coordinate transformation audit

| Boundary | Actual frame / dimensions | Origin, directions, units | Transformation / result |
|---|---|---|---|
| JPEG decode | 1280 × 960 for all four | Top-left, x right, y down, pixels | Original encoded bytes retained; OpenCV-decoded PNG saved without resize |
| SourceAsset | 1280 × 960 | Native pixels | Exact file SHA-256 matches input |
| PageIR | `source_px`, 1280 × 960 | `top_left`, x right, y down | Whole-image region `(0,0,1280,960)`; identity 3×3 matrix and inverse; no crop/pad/rotation |
| Provider input | Original JPEG, byte-exact | Encoded raster | No repository-side resize. Remote model input tensor/preprocessing not exposed; no model response |
| Unresolved BookIR | `geometry.width=1280`, `geometry.height=960` after enforcement | Frame metadata only | No entities, landmarks, authoritative positions, or masks |
| PhysicsScene / solver | No scene | NOT APPLICABLE | Gate returns null; no SI-to-pixel conversion |
| Upload preview | Natural image 1280 × 960 | CSS viewport, x right, y down | Actual DOM values retained under `15_browser/*.json`; this is preview, not simulation mapping |
| Upload-specific CoordinateMapper / SVG / canvas | NOT EXECUTED | NOT APPLICABLE | Any startup/demo mapper values in snapshots belong to unrelated content |

Measured preliminary preview: outer image box `(596,214,226,170)` CSS pixels, 1 px border on all sides, zero padding, `object-fit: contain`, `object-position: 50% 50%`, no CSS transform, CSS zoom 1. Its actual content is 224 × 168; scale is exactly `224/1280 = 168/960 = 0.175`. Therefore the **preview-only** mapping derived from those DOM values is `x_css = 597 + 0.175*x_source`, `y_css = 215 + 0.175*y_source`, with inverse subtraction/division. No landmarks were chosen to make this calculation. Native report snapshots preserve the current measured DOM rectangles and must be used if they differ from the preliminary capture.

Recorded browser: `devicePixelRatio=1`, layout viewport 1418 × 1002, outer window 1440 × 1100, scroll offsets zero, visualViewport scale 1. Browser menu zoom is not exposed directly; CSS zoom and visualViewport scale were recorded rather than guessed. The border explains why the outer preview aspect ratio differs slightly from 4:3. This is not evidence of simulation aspect-ratio distortion.

Each PageIR overlay draws only its actual whole-image region on the lossless decoded original. It is **not** a detected physics object or inferred region. No spatial entity exists to follow further across the pipeline. `runtime_t0_overlay.png`, t=0.5 s, and t=1.0 s are deliberately absent because there is no real runtime for these uploads.

## 7. First-failure table

| Diagram / primary trace | Last known good stage | First suspicious / definitive operational failure | Component | Failure type | Evidence / confidence |
|---|---|---|---|---|---|
| Lens / `TRACE-LENS-20261016-001-NATIVE` | PageIR + matching SDK image bytes | Terminal live provider error | `GeminiVisionProvider.analyze_diagram` → Google SDK | External provider availability; not proven A/B/C | Provider `locals_after.json`, unresolved BookIR, HTTP envelope, browser ERROR; high |
| Circuit / `TRACE-CIRCUIT-20261016-002-NATIVE` | PageIR + matching SDK image bytes | Independently captured provider error | Same component, separate request | External provider availability | Independent call tree and response; high |
| Pendulum / `TRACE-PENDULUM-20261016-003-NATIVE` | PageIR + matching SDK image bytes | Independently captured provider error | Same component, separate request | External provider availability | Independent call tree and response; high |
| Prism / `TRACE-PRISM-20261016-004-NATIVE` | PageIR + matching SDK image bytes | Independently captured provider error | Same component, separate request | External provider availability | Independent call tree and response; high |

**First component corrupting source geometry: NOT ESTABLISHED for any diagram.** Failed analysis did not produce geometry to corrupt. The actual failure chain is provider unavailable → unresolved semantic IR → extraction skipped → readiness false → compiler scene null → browser retry message. The renderer is not implicated by this reproduction.

## 8. Cross-diagram root cause

- **Common operational failure:** Gemini availability on the normal native application path. The four cases did not reach domain-dependent processing.
- **Mechanics-only, optics-only, circuit-only failures:** not assessable in this reproduction; no domain extractor or solver executed.
- **Shared coordinate-system failure:** none demonstrated before the semantic boundary; original bytes and source frame dimensions survive. This does not certify later coordinate mapping.
- **Shared frontend observation:** while awaiting the entire ingest response, the UI remains `UPLOADING` even though the backend is inside VLM analysis. `SimulationApi.ingest` emits its 70% “processing” update only after `fetch` returns. The progress label is therefore not proof that byte upload is stuck. Native failure does eventually produce the existing explicit provider-error retry message.
- **AI/perception:** no successful model interpretation exists. Do not call this misclassification or wrong localization; the model service failed to deliver a result.
- **Compiler/readiness:** executed gates correctly abstain. No evidence that the evaluator accepted a misregistered READY scene; it returned false with the unsupported-classification blocker.
- **Physics engine:** not executed; no numerical failure demonstrated.

The returned `isPhysics=false` on unresolved BookIR is produced by `BookIR.__post_init__` from missing domain/subtype. It is not a model claim that these textbook figures are non-physics. Provider failure context remains in `provenance.error_type/error`.

## 9. Evidence, validation and limitations

For every primary trace:

- `00_source/original.jpg`: untouched byte-exact upload; `original.png`: lossless OpenCV-decoded pixels; `metadata.json`: original/decoded size, EXIF and browser information.
- `identity_chain.json`: upload hash, SourceAsset ID, SDK image hash and trace correlation.
- `http/`: actual request headers, multipart body, HTTP status and full response body from the ASGI boundary.
- `calls/NNNNN_Component.method/`: source location, caller, exact input/output, post-call locals, copied function source/contract, validation and stage summary.
- `arrays/`: binary image payloads, exact ndarray `.npy` artifacts and applicable PNGs; JSON refers to these without truncating tensors.
- PageIR call directory: `actual_overlay_on_source.png` and `transform.json`.
- `15_browser/upload_preview.png`, `final_browser.png`, `final_state.json`, `events.json`, `console.json`: actual application screenshots and observations.
- `TRACE_REPORT.html`: side-by-side source/input/output/overlay and execution/status table.

Trace ID is added as a diagnostic HTTP header and propagated through ASGI `ContextVar` into `asyncio.to_thread`; each saved call and browser observation carries it. It is echoed in the native HTTP response. The ID is deliberately not inserted into the VLM prompt, scene, or physics parameters; external SDK calls are correlated through their local trace context and exact byte hash. Production source values remain untouched.

The SDK recorder preserves all six full request/configuration inputs. On an exception, Python profiling observes a null return during unwind; that is labeled a failed call, **not a JSON null model answer**. The terminal SDK `ServerError` and application `VisionProviderError` text are captured. Earlier individual retry HTTP response bodies/headers are **not exposed in the captured profiler frame** and are not reconstructed. SDK-internal retry attempts below `generate_content`, remote model tensors, and server preprocessing are not claimed to be observed.

The native recorder excludes coroutine suspension from completed outputs. The earlier WSL recorder did not yet distinguish suspension at `ingest_diagram`; its null profiler return is explicitly not treated as an HTTP response. WSL traces were stopped with their pending browser state saved, after the first runner exceeded ten minutes. No 503 is inferred from those WSL sockets.

Instrumentation adds serialization and I/O time, so latency is not a production benchmark. No physics was running in these uploaded requests, and no timing-sensitive physical state was altered. The application startup demo is present in full browser snapshots but is not attributed to an uploaded source. No historical saved scene, unit fixture or hand-edited BookIR was used to bypass the provider.

Validation: all 17 frontend test scripts passed with exit code 0; 247 offline Python unit/integration tests passed with 9 warnings. Logs: `storage/generated/trace_frontend_tests_verified_20261016.log` and `storage/generated/trace_python_tests_20261016.log`. These tests validate the checkout's existing tests, not the unexecuted live perception/rendering branches. No commits were created and no runtime data was staged.

## 10. Root cause ranking

1. **Confirmed current blocker:** terminal Gemini 503 on the standard native connection. Strong direct evidence from independent real uploads and downstream error handling.
2. **Confirmed diagnostic UI limitation:** `UPLOADING` remains visible while semantic work runs; transport and processing progress are not streamed separately. This does not explain misplaced geometry.
3. **Earlier environment-specific blocker:** WSL outgoing connections remained SYN-SENT while native Windows could reach Gemini. Preserved separately and superseded by native traces for the primary conclusion.
4. **Historical perception, grounding, auto-policy, compiler, registration or solver defect:** unresolved. Ranking one of these as the root cause would require the currently unavailable successful semantic output followed by actual domain execution. No unsupported allegation is made.

For visual expected geometry beyond the unchanged source image: **EXPECTED ARTIFACT NOT AVAILABLE — NO GROUND TRUTH EXISTS**. This diagnostic run ends with an observed provider failure, not a successful simulation or a completed geometric root-cause diagnosis.
