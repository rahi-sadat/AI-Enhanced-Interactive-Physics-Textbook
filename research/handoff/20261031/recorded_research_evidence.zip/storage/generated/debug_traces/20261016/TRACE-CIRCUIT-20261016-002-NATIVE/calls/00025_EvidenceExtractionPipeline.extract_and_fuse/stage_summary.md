# EvidenceExtractionPipeline.extract_and_fuse

EXECUTED

File: D:\AugmentedPhysics\ai\evidence\pipeline.py:89
Caller: {'file': 'C:\\Users\\saher\\AppData\\Local\\Programs\\Python\\Python312\\Lib\\concurrent\\futures\\thread.py', 'function': 'run', 'line': 59}
Next component: No nested downstream call captured.
Trace ID: TRACE-CIRCUIT-20261016-002-NATIVE

ACTUAL INPUT: actual_input.json
EXPECTED INPUT: upstream output and function source in contract_or_schema.txt.
INPUT STATUS: PASS

ACTUAL OUTPUT: actual_output.json; locals_after.json contains post-call state
EXPECTED OUTPUT / REFERENCE: original source image; function contract. EXPECTED ARTIFACT NOT AVAILABLE — NO GROUND TRUTH EXISTS
OUTPUT STATUS: PASS

Wrapper EXECUTED but returned early because domain/subtype are null. OCR, CV, segmentation and subtype grounding were NOT EXECUTED. No spatial evidence produced.

PROVENANCE: Actual Python profiler snapshot of named function; ndarray artifacts serialized without modifying runtime objects.
DIFFERENCE FROM INPUT / POSSIBLE INFORMATION LOSS: No manual corrections by recorder. See exact input, returned data, and locals_after for mutations/defaults. 
