# PageIRBuilder.build

EXECUTED

File: D:\AugmentedPhysics\ai\ingestion\PageIRBuilder.py:31
Caller: {'file': 'D:\\AugmentedPhysics\\apps\\api\\main.py', 'function': 'ingest_diagram', 'line': 1628}
Next component: No nested downstream call captured.
Trace ID: TRACE-CIRCUIT-20261016-002-NATIVE

ACTUAL INPUT: actual_input.json
EXPECTED INPUT: upstream output and function source in contract_or_schema.txt.
INPUT STATUS: PASS

ACTUAL OUTPUT: actual_output.json; locals_after.json contains post-call state
EXPECTED OUTPUT / REFERENCE: original source image; function contract. EXPECTED ARTIFACT NOT AVAILABLE — NO GROUND TRUTH EXISTS
OUTPUT STATUS: PASS

Whole-image PageIR preserves native dimensions and top-left source_px; no physics landmark detection claimed.

PROVENANCE: Actual Python profiler snapshot of named function; ndarray artifacts serialized without modifying runtime objects.
DIFFERENCE FROM INPUT / POSSIBLE INFORMATION LOSS: No manual corrections by recorder. See exact input, returned data, and locals_after for mutations/defaults. Adds full-image figure/region metadata. No crop or resize; text_blocks initially empty.
