# BookUnderstandingPipeline._build_unresolved_ir

EXECUTED

File: D:\AugmentedPhysics\ai\ingestion\BookUnderstandingPipeline.py:252
Caller: {'file': 'D:\\AugmentedPhysics\\ai\\ingestion\\BookUnderstandingPipeline.py', 'function': 'analyze', 'line': 134}
Next component: No nested downstream call captured.
Trace ID: TRACE-CIRCUIT-20261016-002-NATIVE

ACTUAL INPUT: actual_input.json
EXPECTED INPUT: upstream output and function source in contract_or_schema.txt.
INPUT STATUS: PASS

ACTUAL OUTPUT: actual_output.json; locals_after.json contains post-call state
EXPECTED OUTPUT / REFERENCE: original source image; function contract. EXPECTED ARTIFACT NOT AVAILABLE — NO GROUND TRUTH EXISTS
OUTPUT STATUS: PASS

Error-handling contract: provider failure becomes UNRESOLVED BookIR with empty entities/parameters, null domain/subtype, and retained VisionProviderError. This PASS means safe error handling, not successful perception. isPhysics=false is a BookIR default, not a model assertion that the source is non-physics.

PROVENANCE: Actual Python profiler snapshot of named function; ndarray artifacts serialized without modifying runtime objects.
DIFFERENCE FROM INPUT / POSSIBLE INFORMATION LOSS: No manual corrections by recorder. See exact input, returned data, and locals_after for mutations/defaults. 
