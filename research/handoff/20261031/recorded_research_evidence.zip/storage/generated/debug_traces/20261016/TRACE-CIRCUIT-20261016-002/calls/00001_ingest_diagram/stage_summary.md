# ingest_diagram

EXECUTED

File: /mnt/d/AugmentedPhysics/apps/api/main.py:1569
Caller: {'file': '/home/torikul/augmentedphysics-audit-venv/lib/python3.12/site-packages/fastapi/routing.py', 'function': 'run_endpoint_function', 'line': 360}
Next component: _get_ingestion_pipeline, UploadService.ingest, UploadService.get_public_url, PageIRBuilder.build
Trace ID: TRACE-CIRCUIT-20261016-002

ACTUAL INPUT: actual_input.json
EXPECTED INPUT: upstream output and function source in contract_or_schema.txt.
INPUT STATUS: PASS

ACTUAL OUTPUT: actual_output.json; locals_after.json contains post-call state
EXPECTED OUTPUT / REFERENCE: original source image; function contract. EXPECTED ARTIFACT NOT AVAILABLE — NO GROUND TRUTH EXISTS
OUTPUT STATUS: PASS

Actual HTTP handler returned success=true with domain failure status=unresolved and scene=null. HTTP 200 is transport success, not simulation success. Full response is under http/.

PROVENANCE: Actual Python profiler snapshot of named function; ndarray artifacts serialized without modifying runtime objects.
DIFFERENCE FROM INPUT / POSSIBLE INFORMATION LOSS: No manual corrections by recorder. See exact input, returned data, and locals_after for mutations/defaults. 
